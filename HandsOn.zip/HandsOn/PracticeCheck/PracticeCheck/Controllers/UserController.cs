﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PracticeCheck.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PracticeCheck.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private DataConnect db = new DataConnect();

        // GET api/<UserController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
         string password = "qwerty";
            try
            {
                var detail = from item in db.User where item.UserId==id select item;
                if (detail == null)
                    return Ok("Not a customer");
                else if (detail.Any(x=>x.Password==password))
                    return Ok("Yes verified User");
                else
                    return Ok("wrong Password");
            }
            catch
            {
                return Ok("Unknown error");
            }
        }

        [HttpPost("SignUp")]
        public IActionResult SignUp([FromBody] User user)
        {
            try
            {
                db.User.Add(user);
                db.SaveChanges();
                return Ok(user);
            }
            catch
            {
                return BadRequest();
            }
        }
    }
}
