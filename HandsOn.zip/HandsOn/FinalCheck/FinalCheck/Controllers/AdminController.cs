﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalCheck.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FinalCheck.Controllers
{
    [Authorize(Roles = "Admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private DataConnect db = new DataConnect();
        // GET: api/<AdminController>
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var list = db.Movie.ToList();
                return Ok(list);
            }
            catch
            {
                return BadRequest();
            }
        }

        // GET api/<AdminController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                var item = db.Movie.Find(id);
                return Ok(item);
            }
            catch
            {
                return BadRequest();
            }
        }

        // POST api/<AdminController>
        [HttpPost]
        public IActionResult Post([FromBody] Movie movie)
        {
            try
            {
                db.Movie.Add(movie);
                db.SaveChanges();
                return Ok(movie);
            }
            catch
            {
                return BadRequest();
            }

        }

        // PUT api/<AdminController>/5
        [HttpPut("{id}")]
        public IActionResult Put([FromBody] Movie movie)
        {
            try
            {
                db.Entry(movie).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                db.SaveChanges();
                return Ok(movie);
            }
            catch
            {
                return BadRequest();
            }
        }

        // DELETE api/<AdminController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                db.Movie.Remove(db.Movie.Find(id));
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }
    }
}
