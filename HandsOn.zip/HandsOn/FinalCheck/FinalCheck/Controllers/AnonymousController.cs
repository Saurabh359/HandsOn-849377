﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalCheck.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FinalCheck.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [ApiController]
    public class AnonymousController : ControllerBase
    {
        private DataConnect db = new DataConnect();

        // GET: api/<AnyuserController>
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var movies = db.Movie.ToList();
                return Ok(movies);
            }
            catch
            {
                return BadRequest();
            }
        }
    }
}
