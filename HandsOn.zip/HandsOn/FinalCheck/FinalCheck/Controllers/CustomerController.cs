﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalCheck.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FinalCheck.Controllers
{
    [Authorize(Roles = "Customer")]
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private DataConnect db = new DataConnect();
        private MovieOperations movie = new MovieOperations();

        // GET: api/<CustomerController>
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = movie.MovieFilter();
                return Ok(items);
            }
            catch
            {
                return BadRequest();
            }
        }

        // GET api/<CustomerController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                var items = movie.FavMovieAccess(id);
                return Ok(items);
            }
            catch
            {
                return BadRequest();
            }
        }

        // POST api/<CustomerController>
        [HttpPost]
        public IActionResult Post([FromBody]Favourite fav)
        {
            try
            {
                db.Favourite.Add(fav);
                db.SaveChanges();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }


        // DELETE api/<CustomerController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id, [FromBody] int movieid)
        {
            try
            {
                var items = movie.FavAccess(id);

                var del = items.First();

                foreach (var i in items)
                {
                    if (i.movie == movieid)
                    {
                        del = i;
                        break;
                    }
                }
                db.Favourite.Remove(del);
                db.SaveChanges();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }
    }
}
